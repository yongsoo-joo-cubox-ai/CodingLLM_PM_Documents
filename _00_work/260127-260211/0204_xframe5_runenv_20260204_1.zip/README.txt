1. 설치 방법
현재 디렉토리 전체를 웹서버 특정 경로로 복사
아래 샘플은 document root에 저장했다는 것을 가정함

2. 브라우저를 시행하여 아래 URL에 접속하여 샘플화면 로딩 확인
http://127.0.0.1:9090/secern.html?xframe_screen_url=/sample

3. 신규 화면 생성시 project\secern\screen 폴더에 저장(신규 화면이 aaa인 경우)
   xframe_screen_url 쿼리 문자열에 화면 경로 지정
http://127.0.0.1:9090/secern.html?xframe_screen_url=/aaa






