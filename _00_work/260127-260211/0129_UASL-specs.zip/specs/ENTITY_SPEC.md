# Entity Spec v1.0 — Domain Model Specification

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Status** | Candidate Recommendation |
| **Date** | 2026-01-29 |
| **JSON Schema** | `schemas/entity/v1.0/root.schema.json` |
| **Depends On** | (none — foundation spec) |
| **Depended On By** | SUIS v1.1, IAS v1.0, Workflow v1.0 |

---

## Abstract

The Entity Spec defines the canonical domain model for UASL applications. It describes entities, their attributes, relations, computed fields, and display hints in a framework-agnostic, machine-verifiable format. All other UASL specifications (SUIS, IAS, Workflow) reference the Entity Spec as their single source of domain truth.

Entity Spec은 UASL 애플리케이션의 정규 도메인 모델을 정의합니다. 엔티티, 속성, 관계, 계산 필드, 표시 힌트를 프레임워크에 종속되지 않는 기계 검증 가능한 형식으로 기술합니다. 다른 모든 UASL 사양(SUIS, IAS, Workflow)은 이 사양을 도메인 진실의 단일 소스(Single Source of Truth)로 참조합니다.

---

## 1. Introduction

### 1.1 Purpose

The Entity Spec provides a single, authoritative representation of domain objects. Whether entities originate from a database schema, an OpenAPI definition, manual authoring, or AI inference, all paths converge to the same canonical format defined here.

### 1.2 Scope

This specification defines:

- Entity structure (name, label, primary key)
- Attribute types, options, and constraints
- Relation types and cardinality
- Computed (derived) fields
- Display hints for default presentation
- Origin tracking via metadata
- Structural and referential validation rules

### 1.3 Relationship to Other UASL Specs

The Entity Spec is the **foundation layer** of the UASL family. All other specs depend on it:

- **SUIS** — `subject.domain` MUST reference an entity name; `fields[].name` MUST reference entity attributes or relations
- **IAS** — `resources[].entity` MUST reference an entity name
- **Workflow** — `workflow.entity` MUST reference an entity name; `workflow.status_field` MUST be an enum attribute on that entity

See [UASL Overview](UASL_OVERVIEW.md) for the full dependency graph.

---

## 2. Conformance

### 2.1 Conformance Levels

| Level | Requirements |
|-------|-------------|
| **L1 Structural** | Document passes JSON Schema validation (`schemas/entity/v1.0/root.schema.json`) |
| **L2 Semantic** | L1 + `primary_key` names an existing attribute; `enum` attributes have `values`; `foreign_key` exists in attributes |
| **L3 Complete** | L2 + all `relation.target` entities exist in the document; `display_field` exists on target entity |

### 2.2 RFC 2119 Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

---

## 3. Terminology

| Term | Korean | Definition |
|------|--------|------------|
| **Entity** | 엔티티 | A named domain object with a primary key, attributes, and optional relations |
| **Attribute** | 속성 | A named, typed field belonging to an entity |
| **Relation** | 관계 | A typed, directed link between two entities |
| **Computed Field** | 계산 필드 | A derived field defined by an expression; always readonly |
| **Display Hint** | 표시 힌트 | Semantic suggestion for default presentation (not layout) |
| **Canonical** | 정규 | The authoritative, validated form of an entity (as opposed to draft/inferred) |
| **Primary Key** | 기본 키 | The attribute that uniquely identifies each instance of an entity |
| **Foreign Key** | 외래 키 | An attribute that references another entity's primary key |

---

## 4. Specification (NORMATIVE)

### 4.1 Design Principles

1. **Single source of truth** — all UASL specs reference Entity Spec for domain knowledge.
2. **Authoritative or inferred** — both mechanical extraction and AI inference converge to the same canonical format.
3. **Relations unlock UI patterns** — dropdowns, master/detail views, and joins derive from relation metadata.
4. **Machine-verifiable** — strict structural and referential validation; fail-fast on errors.

### 4.2 Document Structure

A conforming Entity Spec document MUST contain:

```yaml
entity_version: "1.0"       # REQUIRED — spec version

entities:                    # REQUIRED — at least one entity
  entity_name: { ... }
```

- `entity_version` MUST be the string `"1.0"`.
- `entities` MUST be a non-empty object where each key is an entity name.
- Entity names SHOULD use `snake_case`.

### 4.3 Entity Definition

Each entity MUST contain `primary_key` and `attributes`. All other fields are OPTIONAL.

```yaml
entities:
  task:
    label: Task                     # OPTIONAL — human-readable name
    primary_key: id                 # REQUIRED — attribute name

    meta: { ... }                   # OPTIONAL — origin tracking
    attributes: { ... }            # REQUIRED — at least one attribute
    relations: { ... }             # OPTIONAL
    computed: { ... }              # OPTIONAL
    display: { ... }              # OPTIONAL — presentation hints
```

- `primary_key` MUST name an attribute defined in `attributes`.
- `label` SHOULD be a human-readable, singular noun.

### 4.4 Attributes

Each attribute MUST declare a `type`. All other fields are OPTIONAL.

```yaml
attributes:
  title:
    type: string
    required: true
    label: "Title"
    constraints:
      max_length: 200
```

#### 4.4.1 Attribute Types

| Type | Description | Applicable Constraints |
|------|-------------|------------------------|
| `string` | Short text | `max_length`, `min_length`, `pattern` |
| `text` | Long text | `max_length` |
| `integer` | Whole number | `min`, `max` |
| `decimal` | Precise number | `min`, `max`, `precision`, `scale` |
| `currency` | Money value | `min` (defaults to 0), `precision`, `scale` |
| `boolean` | True/false | — |
| `date` | Date only (no time) | `min`, `max` |
| `datetime` | Date and time | `min`, `max` |
| `uuid` | UUID v4 identifier | — |
| `enum` | Fixed set of values | `values` (REQUIRED for enum) |

#### 4.4.2 Attribute Options

| Option | Type | Description |
|--------|------|-------------|
| `required` | boolean | Attribute MUST have a value |
| `unique` | boolean | No duplicate values allowed |
| `readonly` | boolean | Attribute cannot be modified after creation |
| `default` | any | Default value; MAY be a literal or the string `"now()"` for timestamps |
| `label` | string | Human-readable display label |
| `values` | string[] | Allowed values; REQUIRED when `type` is `enum` |
| `constraints` | object | Validation constraints (see §4.4.3) |

#### 4.4.3 Constraints

| Constraint | Type | Applicable To |
|------------|------|---------------|
| `min` | number | `integer`, `decimal`, `currency`, `date`, `datetime` |
| `max` | number | `integer`, `decimal`, `currency`, `date`, `datetime` |
| `min_length` | integer | `string` |
| `max_length` | integer | `string`, `text` |
| `pattern` | string | `string` (regex) |
| `precision` | integer | `decimal`, `currency` |
| `scale` | integer | `decimal`, `currency` |

### 4.5 Relations

Each relation MUST declare `type` and `target`.

```yaml
relations:
  assignee:
    type: many_to_one
    target: user
    foreign_key: assignee_id
    display_field: name
    nullable: true
    on_delete: set_null
```

#### 4.5.1 Relation Types

| Type | Cardinality | Example | Required Fields |
|------|-------------|---------|-----------------|
| `one_to_one` | 1:1 | User → Profile | `target` |
| `many_to_one` | N:1 | Task → User (assignee) | `target`, `foreign_key` |
| `one_to_many` | 1:N | User → Tasks | `target`, `mapped_by` |
| `many_to_many` | M:N | Task ↔ Tags | `target`, `join_table` |

#### 4.5.2 Relation Options

| Option | Type | Description |
|--------|------|-------------|
| `target` | string | **REQUIRED** — target entity name; MUST exist in entities |
| `foreign_key` | string | FK attribute name; REQUIRED for `many_to_one` |
| `display_field` | string | Attribute on target used for display (e.g., dropdown labels) |
| `nullable` | boolean | Whether the FK attribute MAY be null |
| `on_delete` | enum | Delete behavior: `cascade`, `restrict`, or `set_null` |
| `mapped_by` | string | Inverse relation name on target; REQUIRED for `one_to_many` |
| `join_table` | string | Join table name; REQUIRED for `many_to_many` |
| `join_columns` | object | FK column names in join table: `{ source, target }` |

#### 4.5.3 What Relations Enable

| UI Feature | Relation Type | Mechanism |
|------------|---------------|-----------|
| Foreign key dropdown | `many_to_one` | `display_field` populates options |
| Master/detail grid | `one_to_many` | Parent row opens child collection |
| Inline collection | `many_to_many` | Multi-select or tag input |
| JOIN in browse | `many_to_one` | `display_field` shown in grid column |
| Cascade delete | `on_delete: cascade` | Automatic cleanup of dependent records |

### 4.6 Computed Fields

Computed fields are derived from expressions. They are always readonly.

```yaml
computed:
  full_name:
    expression: "first_name || ' ' || last_name"
    type: string
    readonly: true
```

- `expression` MUST be a string representing the derivation formula.
- `type` MUST be a valid attribute type.
- `readonly` MUST be `true` (default). Adapters MUST treat computed fields as non-editable.

### 4.7 Display Hints

Display hints are semantic suggestions, not layout instructions. Adapters MAY interpret them differently.

```yaml
display:
  default_sort: created_at desc
  default_fields: [title, status, assignee]
  search_fields: [title, description]
```

- `default_sort` — OPTIONAL, format: `field_name [asc|desc]`.
- `default_fields` — OPTIONAL, list of field names for default list views.
- `search_fields` — OPTIONAL, list of field names to include in search.

### 4.8 Meta / Source Tracking

The `meta` block tracks the origin of an entity definition.

```yaml
meta:
  source: db | inferred | openapi | manual
  confidence: 0.95
```

- `source` — OPTIONAL, indicates how the entity was created.
- `confidence` — OPTIONAL, a number between 0 and 1; SHOULD be present when `source` is `inferred`.

### 4.9 Validation Rules

#### 4.9.1 Structural Validation (L1 + L2)

| Rule | Error Code |
|------|------------|
| `entity_version` MUST exist and equal `"1.0"` | `MISSING_VERSION` |
| `entities` MUST NOT be empty | `NO_ENTITIES` |
| Each entity MUST have `primary_key` | `MISSING_PK` |
| `primary_key` MUST name an attribute in `attributes` | `PK_NOT_FOUND` |
| `enum` attributes MUST have non-empty `values` | `MISSING_ENUM_VALUES` |

#### 4.9.2 Referential Validation (L3)

| Rule | Error Code |
|------|------------|
| `relation.target` MUST name an entity in `entities` | `UNKNOWN_TARGET` |
| `foreign_key` MUST name an attribute in the same entity | `FK_NOT_FOUND` |
| `display_field` MUST name an attribute on the target entity | `DISPLAY_FIELD_NOT_FOUND` |
| `mapped_by` MUST name a relation on the target entity | `MAPPED_BY_NOT_FOUND` |

**Fail-fast. No silent coercion.**

---

## 5. Cross-Spec References (NORMATIVE)

### 5.1 Entity Spec → SUIS

SUIS screens reference entities via `subject.domain`:

```yaml
# In SUIS
subject:
  domain: task          # MUST exist in entity-spec.entities
```

SUIS field names MUST match entity attributes or relation names. The Semantic Validator resolves fields by looking up the entity.

### 5.2 Entity Spec → IAS

IAS resources reference entities via `resources[].entity`:

```yaml
# In IAS
resources:
  task:
    entity: task        # MUST exist in entity-spec.entities
```

### 5.3 Entity Spec → Workflow

Workflow specs reference entities via `workflow.entity` and bind to the entity's status field:

```yaml
# In Workflow Spec
workflow:
  entity: task              # MUST exist in entity-spec.entities
  status_field: status      # MUST be an enum attribute on task
```

State names in the workflow MUST match the enum `values` of `status_field`.

---

## 6. JSON Schema Reference

The normative JSON Schema for Entity Spec v1.0 is located at:

```
schemas/entity/v1.0/root.schema.json
```

Key features of the schema:

- Enforces `entity_version` and `entities` as required top-level properties
- Validates attribute types against the fixed enum
- Conditionally requires `values` when attribute type is `enum`
- Validates relation types and cardinality
- Conditionally requires `join_table` for `many_to_many` relations
- Disallows additional properties at all levels

See [Appendix B](#appendix-b-full-json-schema) for an inline copy.

---

## 7. Examples (INFORMATIVE)

### 7.1 Complete Entity Spec

```yaml
entity_version: "1.0"

entities:
  task:
    label: Task
    primary_key: id

    meta:
      source: db

    attributes:
      id:
        type: uuid
        required: true

      title:
        type: string
        required: true
        label: "Title"
        constraints:
          max_length: 200

      description:
        type: text

      status:
        type: enum
        values: [pending, in_progress, completed, cancelled]
        default: pending

      due_date:
        type: date

      created_at:
        type: datetime
        required: true
        default: now()
        readonly: true

      assignee_id:
        type: uuid

    relations:
      assignee:
        type: many_to_one
        target: user
        foreign_key: assignee_id
        display_field: name
        nullable: true
        on_delete: set_null

    display:
      default_sort: created_at desc
      default_fields: [title, status, assignee, due_date]

  user:
    label: User
    primary_key: id

    attributes:
      id:
        type: uuid
        required: true

      name:
        type: string
        required: true

      email:
        type: string
        required: true
        unique: true

    relations:
      tasks:
        type: one_to_many
        target: task
        mapped_by: assignee
```

---

## 8. Implementation Notes (INFORMATIVE)

### 8.1 Entity Canonicalization Pipeline

Entity Specs can be produced from multiple input sources. A canonicalization pipeline normalizes these sources into the format defined in this specification.

#### Mode A: Authoritative (Mechanical)

```
SQL Schema        →  Entity Normalizer  →  Canonical Entity Spec
OpenAPI           →  Entity Normalizer  →  Canonical Entity Spec
Prisma/TypeORM    →  Entity Normalizer  →  Canonical Entity Spec
Manual YAML       →  Validation         →  Canonical Entity Spec
```

Normalizer responsibilities:

- Map source types to Entity Spec types (e.g., `VARCHAR` → `string`, `INT` → `integer`)
- Detect primary keys
- Infer relations via foreign keys
- Convert CHECK constraints to enums
- Add labels from column comments

#### Mode B: Inferred (Probabilistic)

```
Natural Language  →  LLM Inferencer  →  Draft Entity Spec
                                              ↓
                                    User Confirmation Loop
                                              ↓
                                    Canonical Entity Spec
```

Inferred entities:

- Are marked with `meta.source: inferred`
- Include a `meta.confidence` score
- Require explicit user approval before promotion to canonical
- Must never proceed to downstream spec generation (SUIS, IAS) without confirmation

### 8.2 Entity Inferencer

When using AI to infer entities from natural language:

- The LLM acts as a hypothesis generator, not an authority.
- A structural validator gates all LLM output before it reaches any user-facing flow.
- The user is the final authority: inferred entities require explicit acceptance.
- Silence is preferred over hallucination — the LLM is instructed to omit uncertain elements.

### 8.3 File Management

```
entity-spec.yaml           # Canonical (after approval)
entity-spec.inferred.yaml  # Draft (before approval)
```

Canonical files are never overwritten automatically by inference results.

### 8.4 Mixed Mode Support

Authoritative and inferred entities can coexist in a single document:

```yaml
entities:
  user:
    meta:
      source: db          # Mechanically extracted

  task:
    meta:
      source: inferred    # AI-inferred, user-confirmed
      confidence: 0.85
```

---

## Appendix A: Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-27 | Initial release |
| 1.0 | 2026-01-29 | Restructured to language standard format |

---

## Appendix B: Full JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://coder.local/schemas/entity/v1.0/root.schema.json",
  "title": "Entity Specification v1.0",
  "description": "Canonical domain model specification for UASL semantic compiler",
  "type": "object",
  "required": ["entity_version", "entities"],
  "properties": {
    "entity_version": {
      "type": "string",
      "enum": ["1.0"],
      "description": "Entity spec version"
    },
    "entities": {
      "type": "object",
      "minProperties": 1,
      "additionalProperties": { "$ref": "#/$defs/entity" },
      "description": "Map of entity name to entity definition"
    }
  },

  "$defs": {
    "entity": {
      "type": "object",
      "required": ["primary_key", "attributes"],
      "properties": {
        "label": {
          "type": "string",
          "description": "Human-readable name"
        },
        "primary_key": {
          "type": "string",
          "description": "Primary key attribute name"
        },
        "meta": { "$ref": "#/$defs/meta" },
        "attributes": {
          "type": "object",
          "minProperties": 1,
          "additionalProperties": { "$ref": "#/$defs/attribute" },
          "description": "Map of attribute name to definition"
        },
        "relations": {
          "type": "object",
          "additionalProperties": { "$ref": "#/$defs/relation" },
          "description": "Map of relation name to definition"
        },
        "computed": {
          "type": "object",
          "additionalProperties": { "$ref": "#/$defs/computed" },
          "description": "Computed/derived fields"
        },
        "display": { "$ref": "#/$defs/display_hints" }
      },
      "additionalProperties": false
    },

    "meta": {
      "type": "object",
      "properties": {
        "source": {
          "type": "string",
          "enum": ["db", "inferred", "openapi", "manual"],
          "description": "Origin of entity definition"
        },
        "confidence": {
          "type": "number",
          "minimum": 0,
          "maximum": 1,
          "description": "Confidence score for inferred entities"
        }
      },
      "additionalProperties": false
    },

    "attribute": {
      "type": "object",
      "required": ["type"],
      "properties": {
        "type": {
          "type": "string",
          "enum": ["string", "text", "integer", "decimal", "currency", "boolean", "date", "datetime", "uuid", "enum"],
          "description": "Attribute data type"
        },
        "required": {
          "type": "boolean",
          "description": "Whether attribute is required"
        },
        "unique": {
          "type": "boolean",
          "description": "Whether attribute must be unique"
        },
        "readonly": {
          "type": "boolean",
          "description": "Whether attribute is read-only"
        },
        "default": {
          "description": "Default value"
        },
        "label": {
          "type": "string",
          "description": "Display label"
        },
        "values": {
          "type": "array",
          "items": { "type": "string" },
          "minItems": 1,
          "description": "Allowed values for enum type"
        },
        "constraints": { "$ref": "#/$defs/constraints" }
      },
      "allOf": [
        {
          "if": {
            "properties": { "type": { "const": "enum" } }
          },
          "then": {
            "required": ["values"]
          }
        }
      ],
      "additionalProperties": false
    },

    "constraints": {
      "type": "object",
      "properties": {
        "min": {
          "type": "number",
          "description": "Minimum value (for numeric types)"
        },
        "max": {
          "type": "number",
          "description": "Maximum value (for numeric types)"
        },
        "min_length": {
          "type": "integer",
          "minimum": 0,
          "description": "Minimum length (for string types)"
        },
        "max_length": {
          "type": "integer",
          "minimum": 1,
          "description": "Maximum length (for string types)"
        },
        "pattern": {
          "type": "string",
          "description": "Regex pattern (for string types)"
        },
        "precision": {
          "type": "integer",
          "minimum": 1,
          "description": "Total digits (for decimal/currency)"
        },
        "scale": {
          "type": "integer",
          "minimum": 0,
          "description": "Decimal places (for decimal/currency)"
        }
      },
      "additionalProperties": false
    },

    "relation": {
      "type": "object",
      "required": ["type", "target"],
      "properties": {
        "type": {
          "type": "string",
          "enum": ["one_to_one", "one_to_many", "many_to_one", "many_to_many"],
          "description": "Relation cardinality"
        },
        "target": {
          "type": "string",
          "description": "Target entity name"
        },
        "foreign_key": {
          "type": "string",
          "description": "Foreign key attribute name (for many_to_one)"
        },
        "display_field": {
          "type": "string",
          "description": "Field to display for dropdown labels"
        },
        "nullable": {
          "type": "boolean",
          "description": "Whether relation is optional"
        },
        "on_delete": {
          "type": "string",
          "enum": ["cascade", "restrict", "set_null"],
          "description": "Delete behavior"
        },
        "mapped_by": {
          "type": "string",
          "description": "Inverse relation name (for one_to_many)"
        },
        "join_table": {
          "type": "string",
          "description": "Join table name (for many_to_many)"
        },
        "join_columns": {
          "type": "object",
          "properties": {
            "source": {
              "type": "string",
              "description": "Source FK column in join table"
            },
            "target": {
              "type": "string",
              "description": "Target FK column in join table"
            }
          },
          "required": ["source", "target"],
          "additionalProperties": false,
          "description": "FK columns in join table (for many_to_many)"
        }
      },
      "allOf": [
        {
          "if": {
            "properties": { "type": { "const": "many_to_many" } }
          },
          "then": {
            "required": ["join_table"]
          }
        }
      ],
      "additionalProperties": false
    },

    "computed": {
      "type": "object",
      "required": ["expression", "type"],
      "properties": {
        "expression": {
          "type": "string",
          "description": "SQL expression for computed value"
        },
        "type": {
          "type": "string",
          "description": "Result type"
        },
        "readonly": {
          "type": "boolean",
          "default": true,
          "description": "Computed fields are always readonly"
        }
      },
      "additionalProperties": false
    },

    "display_hints": {
      "type": "object",
      "properties": {
        "default_sort": {
          "type": "string",
          "description": "Default sort order (e.g., 'created_at desc')"
        },
        "default_fields": {
          "type": "array",
          "items": { "type": "string" },
          "description": "Default fields to display in lists"
        },
        "search_fields": {
          "type": "array",
          "items": { "type": "string" },
          "description": "Fields to include in search"
        }
      },
      "additionalProperties": false
    }
  }
}
```

---

*Document Version: 1.0*
*Last Updated: 2026-01-29*
