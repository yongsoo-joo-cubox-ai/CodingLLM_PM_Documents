# SUIS v1.1 — Semantic UI Specification

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.1 |
| **Status** | Candidate Recommendation |
| **Date** | 2026-01-29 |
| **JSON Schema** | `schemas/suis/v1.1/root.schema.json` |
| **Depends On** | Entity Spec v1.0, IAS v1.0 |
| **Depended On By** | Workflow v1.0 (optional) |

---

## Abstract

The Semantic UI Specification (SUIS) is an intent-driven, framework-agnostic intermediate representation for user interfaces. It describes WHAT users intend to do — browse data, edit records, approve documents — without specifying HOW the UI is built. Framework adapters transform SUIS into platform-specific code (xframe5, Vue, React, etc.).

SUIS(Semantic UI Specification)는 의도 기반의 프레임워크 비종속적 사용자 인터페이스 중간 표현입니다. 사용자가 무엇을 하려는지(데이터 탐색, 레코드 편집, 문서 승인 등)를 기술하며, UI가 어떻게 구축되는지는 명시하지 않습니다. 프레임워크 어댑터가 SUIS를 플랫폼별 코드(xframe5, Vue, React 등)로 변환합니다.

---

## 1. Introduction

### 1.1 Purpose

SUIS provides a universal UI description that is:

- **Semantic** — describes intent and data, not widgets and events
- **Framework-agnostic** — no grids, no datasources, no click handlers
- **Machine-verifiable** — every field, filter, and operation is validated against the domain model
- **Adaptable** — the same SUIS document targets any UI framework via adapters

### 1.2 Scope

This specification defines:

- Screen definitions with semantic subjects (domain, purpose)
- Display blocks (collection, single, summary) with fields and filters
- Operations with semantic intents and triggers
- Navigation between screens
- Permission declarations
- Reusable component definitions
- Structural and semantic validation rules

### 1.3 Relationship to Other UASL Specs

- **Entity Spec** — `subject.domain` and `fields[].name` reference entities and their attributes
- **IAS** — each operation `intent` MUST have a corresponding IAS intent mapping
- **Workflow** — workflow transition events (approve, reject) appear as SUIS operations

See [UASL Overview](UASL_OVERVIEW.md) for the full dependency graph.

---

## 2. Conformance

### 2.1 Conformance Levels

| Level | Requirements |
|-------|-------------|
| **L1 Structural** | Document passes JSON Schema validation (`schemas/suis/v1.1/root.schema.json`) |
| **L2 Semantic** | L1 + `delete` intent has `confirmation`; `edit`/`view` with `opens` has valid trigger; purpose-intent compatibility |
| **L3 Complete** | L2 + `subject.domain` exists in Entity Spec; `fields[].name` exists on entity; `opens` targets exist; intents map to IAS |

### 2.2 RFC 2119 Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

---

## 3. Terminology

| Term | Korean | Definition |
|------|--------|------------|
| **Screen** | 화면 | A named UI unit with a subject, display, operations, and optional navigation |
| **Subject** | 주제 | The semantic anchor of a screen: which entity domain and what purpose |
| **Purpose** | 목적 | The screen's role: `browse`, `view`, `create`, `edit`, `dashboard`, `wizard` |
| **Display Block** | 표시 블록 | A data presentation area with a type and field list |
| **Field** | 필드 | A reference to an entity attribute with optional display hints |
| **Filter** | 필터 | A search criterion binding an entity field to an operator and input type |
| **Operation** | 작업 | A user action defined by intent, trigger, and optional navigation |
| **Intent** | 의도 | The semantic action: `search`, `create`, `edit`, `delete`, `approve`, etc. |
| **Trigger** | 트리거 | The semantic interaction that initiates an operation (NOT a DOM event) |
| **Component** | 컴포넌트 | A reusable display block that can be referenced across screens |

---

## 4. Specification (NORMATIVE)

### 4.1 Design Principles

1. **Describe WHAT users intend**, not HOW UI is built.
2. **No framework concepts** — no grids, datasources, click handlers, or component names.
3. **No pixel/layout control** — no positions, sizes, or CSS.
4. **Presentation via semantic hints only** — `width_hint`, `align_hint`, not pixel values.
5. **Everything MUST be machine-verifiable** — fail-fast on invalid references.
6. **Adapters own rendering and events** — SUIS declares intent; adapters decide implementation.

### 4.2 Explicit Non-Goals

SUIS MUST NOT contain:

| Excluded | Reason |
|----------|--------|
| Grids / DataSources | Adapter responsibility |
| API URLs / endpoints | Derived from IAS |
| Pixel positions (x, y, width, height) | Layout is the adapter's job |
| DOM events (click, dblclick, onchange) | Use semantic triggers |
| Widget names (Button, Input, SBGrid) | Use format + purpose |
| Framework-specific constructs | Adapters handle all framework specifics |

### 4.3 Document Structure

A conforming SUIS document MUST contain:

```yaml
ui:
  suis_version: "1.1"        # REQUIRED

  screens:                     # REQUIRED — at least one screen
    screen_id: { ... }

  components:                  # OPTIONAL — reusable blocks
    component_id: { ... }
```

- `suis_version` MUST be the string `"1.1"`.
- `screens` MUST be a non-empty object where each key is a screen ID.
- `components` is OPTIONAL.

### 4.4 Screen

Each screen MUST contain `subject`, `display`, and `operations`.

```yaml
screens:
  task_browser:
    subject: { ... }           # REQUIRED — semantic anchor
    display: { ... }           # REQUIRED — what data is visible
    operations: [ ... ]        # REQUIRED — what actions are available
    navigation: { ... }        # OPTIONAL — screen-to-screen links
    permissions: { ... }       # OPTIONAL — role-based access
```

### 4.5 Subject (Semantic Anchor)

The `subject` identifies what entity this screen operates on and for what purpose.

```yaml
subject:
  domain: task                 # REQUIRED — entity name (MUST exist in Entity Spec)
  purpose: browse              # REQUIRED — screen purpose
  title: "Task Management"    # REQUIRED — human-readable title
  description: "View and manage tasks"  # OPTIONAL
```

#### 4.5.1 Purpose Enum

| Purpose | Description |
|---------|-------------|
| `browse` | List/search view with multiple records |
| `view` | Read-only detail view of a single record |
| `create` | New record creation form |
| `edit` | Edit form for an existing record |
| `dashboard` | Aggregated summary view |
| `wizard` | Multi-step guided process |

### 4.6 Display

The `display` section defines what data is visible on the screen.

```yaml
display:
  primary:                     # REQUIRED — main content area
    type: collection
    fields: [ ... ]

  secondary:                   # OPTIONAL — additional areas (KPIs, sidebars)
    - type: summary
      fields: [ ... ]

  filters:                     # OPTIONAL — for browse/search screens
    - field: status
      operator: eq
      input: dropdown
      options: ["pending", "active", "done"]
```

- `primary` is REQUIRED and MUST have a `type` and at least one field.
- `secondary` is OPTIONAL; each entry is a display block.
- `filters` is OPTIONAL; used for browse and search screens.

#### 4.6.1 Display Block Types

| Type | Description |
|------|-------------|
| `collection` | Multiple records (grid/list) |
| `single` | One record (form/detail) |
| `summary` | Aggregated data (KPIs, counts) |

### 4.7 Fields

Each field MUST have a `name` referencing an entity attribute or relation.

```yaml
fields:
  - name: status              # REQUIRED — entity attribute name
    label: "Status"           # OPTIONAL — display label
    format: enum              # OPTIONAL — data format
    sortable: true            # OPTIONAL — allow sorting
    visible: true             # OPTIONAL — show/hide (default: true)
    width_hint: medium        # OPTIONAL — narrow | medium | wide | fill
    align_hint: start         # OPTIONAL — start | center | end
    editable: false           # OPTIONAL — inline editing
    required: true            # OPTIONAL — validation hint
```

#### 4.7.1 Field Format

| Format | Description |
|--------|-------------|
| `text` | String display |
| `integer` | Whole number |
| `decimal` | Precise number |
| `currency` | Money value |
| `date` | Date only |
| `datetime` | Date and time |
| `enum` | Fixed value set |
| `boolean` | True/false toggle |

#### 4.7.2 Width Hint

| Value | Semantic Meaning |
|-------|------------------|
| `narrow` | Minimal space (IDs, status badges) |
| `medium` | Standard column width |
| `wide` | Extended space (titles, descriptions) |
| `fill` | Expand to fill available space |

#### 4.7.3 Align Hint

| Value | Semantic Meaning |
|-------|------------------|
| `start` | Left-aligned (default for text) |
| `center` | Center-aligned (status, boolean) |
| `end` | Right-aligned (numbers, currency) |

### 4.8 Filters

Filters define search criteria for browse/search screens.

```yaml
filters:
  - field: status             # REQUIRED — entity attribute name
    operator: eq              # REQUIRED — comparison operator
    input: dropdown           # OPTIONAL — input control type
    options: [...]            # OPTIONAL — for dropdown inputs
```

#### 4.8.1 Filter Operators

| Operator | Description |
|----------|-------------|
| `eq` | Equal to |
| `ne` | Not equal to |
| `gt` | Greater than |
| `lt` | Less than |
| `range` | Between two values |
| `contains` | String contains |

#### 4.8.2 Filter Input Types

| Input | Description |
|-------|-------------|
| `dropdown` | Select from options |
| `text` | Free text input |
| `date_range` | Date range picker |

### 4.9 Operations (User Intentions)

Operations declare what actions users can perform on the screen.

```yaml
operations:
  - intent: search

  - intent: create
    opens: task_editor

  - intent: edit
    trigger: activate_item
    opens: task_editor

  - intent: delete
    trigger: bulk_selection
    confirmation: "Delete selected tasks?"

  - intent: submit
    success_feedback: "Saved successfully"
    post_action: close
```

#### 4.9.1 Intent Enum

| Intent | Description |
|--------|-------------|
| `browse` | View list of records |
| `view` | View single record detail |
| `search` | Filter/search records |
| `create` | Create new record |
| `edit` | Edit existing record |
| `delete` | Delete record(s) |
| `submit` | Submit form data |
| `approve` | Approve (workflow) |
| `reject` | Reject (workflow) |
| `export` | Export data |
| `import` | Import data |
| `custom` | Custom operation |

#### 4.9.2 Trigger Enum (Semantic, NOT DOM)

| Trigger | Description |
|---------|-------------|
| `select_item` | Row/item selection |
| `activate_item` | Open/edit action (semantically: user wants to interact with this item) |
| `bulk_selection` | Multi-select action |
| `confirm_action` | Explicit user confirmation |
| `value_change` | Reactive form change |
| `automatic` | On load / timer |

Triggers are semantic interactions. Adapters map them to framework-specific events.

#### 4.9.3 Operation Hints (v1.1)

| Hint | Description |
|------|-------------|
| `success_feedback` | Message shown to user after successful completion |
| `post_action` | Behavior after completion: `refresh`, `close`, or `navigate` |
| `confirmation` | Confirmation message; REQUIRED for `delete` intent |
| `opens` | Target screen ID to navigate to |

### 4.10 Navigation

Navigation defines screen-to-screen links.

```yaml
navigation:
  to_editor:
    target: task_editor       # REQUIRED — target screen ID
    mode: modal               # OPTIONAL — modal | full (default: full)
```

- `target` MUST reference a screen ID defined in `screens`.
- `mode` defaults to `full` (full-page navigation).

### 4.11 Permissions

Permissions declare role-based access to the screen.

```yaml
permissions:
  roles: [admin, manager, user]
```

- `roles` is an array of role names that MAY access this screen.
- Permission enforcement is the responsibility of the runtime, not the adapter.

### 4.12 Components (Reusable Blocks)

Components are reusable display blocks that can be shared across screens.

```yaml
components:
  task_summary:
    type: summary
    fields:
      - name: total_count
        format: integer
      - name: pending_count
        format: integer
```

### 4.13 Validation Rules

#### 4.13.1 Structural Validation (L1 + L2)

| Rule | Error Code |
|------|------------|
| `suis_version` MUST exist and equal `"1.1"` | `MISSING_VERSION` |
| `screens` MUST NOT be empty | `NO_SCREENS` |
| `subject.purpose` MUST be a valid enum | `INVALID_PURPOSE` |
| `display.primary` MUST exist | `MISSING_PRIMARY_DISPLAY` |
| `operations` array MUST exist and be non-empty | `MISSING_OPERATIONS` |
| `delete` intent MUST have `confirmation` | `MISSING_CONFIRMATION` |
| `edit`/`view` with `opens` MUST have a valid trigger | `INVALID_TRIGGER` |

#### 4.13.2 Cross-Spec Validation (L3)

| Rule | Error Code |
|------|------------|
| `subject.domain` MUST exist in Entity Spec | `UNKNOWN_ENTITY` |
| `fields[].name` MUST exist on the entity (attribute or relation) | `UNKNOWN_FIELD` |
| `filters[].field` MUST exist on the entity | `UNKNOWN_FILTER_FIELD` |
| `opens` target MUST exist in `screens` | `INVALID_SCREEN_REF` |
| `navigation.target` MUST exist in `screens` | `INVALID_NAV_TARGET` |
| Every operation `intent` MUST have a corresponding IAS mapping | `UNMAPPED_INTENT` |

**Fail-fast. No silent coercion.**

---

## 5. Cross-Spec References (NORMATIVE)

### 5.1 SUIS → Entity Spec

Screens reference entities via `subject.domain`:

```yaml
subject:
  domain: task          # MUST exist in entity-spec.entities
```

Field names in `display.*.fields[].name` MUST match entity attributes or relation names. The Semantic Validator resolves fields by looking up the entity.

### 5.2 SUIS → IAS

Every operation intent MUST have a corresponding IAS intent:

```yaml
# SUIS operation
operations:
  - intent: search      # MUST exist in IAS.resources.{domain}.intents
```

### 5.3 SUIS → Workflow

Workflow operations (approve, reject) in SUIS correspond to workflow transitions:

```yaml
operations:
  - intent: approve     # Corresponds to workflow transition event
    trigger: confirm_action
```

### 5.4 Required External Specs

SUIS is incomplete without:

```
entity-spec.yaml     # Domain model (fields, types)
api-spec.yaml        # Intent → endpoint mapping (IAS)
workflow-spec.yaml   # Optional: state machines
```

---

## 6. JSON Schema Reference

The normative JSON Schema for SUIS v1.1 is located at:

```
schemas/suis/v1.1/root.schema.json
```

Key features of the schema:

- Enforces `ui` with `suis_version` and `screens` as required
- Validates purpose, intent, trigger, and format against fixed enums
- Validates display block types (`collection`, `single`, `summary`)
- Validates field hints (`width_hint`, `align_hint`)
- Validates filter operators and input types
- Disallows additional properties at all levels

See [Appendix B](#appendix-b-full-json-schema) for an inline copy.

---

## 7. Examples (INFORMATIVE)

### 7.1 Complete SUIS Document

```yaml
ui:
  suis_version: "1.1"

  screens:
    task_browse:
      subject:
        domain: task
        purpose: browse
        title: "Task Management"
        description: "View and manage all tasks"

      display:
        primary:
          type: collection
          fields:
            - name: id
              label: "ID"
              format: integer
              width_hint: narrow
              align_hint: end
              sortable: true
            - name: title
              label: "Title"
              format: text
              width_hint: wide
              sortable: true
            - name: assignee
              label: "Assignee"
              format: text
              width_hint: medium
            - name: due_date
              label: "Due Date"
              format: date
              width_hint: medium
              sortable: true
            - name: status
              label: "Status"
              format: enum
              width_hint: narrow
              align_hint: center

        filters:
          - field: status
            operator: eq
            input: dropdown
            options: ["pending", "in_progress", "completed"]
          - field: due_date
            operator: range
            input: date_range
          - field: title
            operator: contains
            input: text

      operations:
        - intent: search
        - intent: create
          opens: task_edit
        - intent: edit
          trigger: activate_item
          opens: task_edit
        - intent: delete
          trigger: bulk_selection
          confirmation: "Delete selected tasks?"
        - intent: export

      navigation:
        to_editor:
          target: task_edit
          mode: modal

      permissions:
        roles: [admin, manager, user]

    task_edit:
      subject:
        domain: task
        purpose: edit
        title: "Task Editor"

      display:
        primary:
          type: single
          fields:
            - name: title
              label: "Title"
              format: text
              required: true
            - name: description
              label: "Description"
              format: text
            - name: assignee
              label: "Assignee"
              format: text
            - name: due_date
              label: "Due Date"
              format: date
            - name: status
              label: "Status"
              format: enum

      operations:
        - intent: submit
          success_feedback: "Task saved successfully"
          post_action: close
        - intent: browse
          opens: task_browse

      permissions:
        roles: [admin, manager, user]
```

---

## 8. Implementation Notes (INFORMATIVE)

### 8.1 Adapter Responsibility

Adapters generate all framework-specific artifacts from SUIS. SUIS never produces:

- Layout (grid, flex, absolute positioning)
- DataSources (ds_search, ds_main)
- Widgets (SBGrid, el-table, v-data-table)
- DOM events (onclick, onchange, @dblclick)
- API wiring (fetch, axios)
- Popup sizing and positioning
- CSS/styling

### 8.2 Adapter Trigger Mappings

Adapters translate semantic triggers to framework-specific events:

| SUIS Trigger | xframe5 | Vue |
|--------------|---------|-----|
| `activate_item` | `row_double_click` | `@dblclick` |
| `select_item` | `row_click` | `@click` |
| `value_change` | `onchange` | `@change` / `v-model` |
| `confirm_action` | `button_click` | `@click` + confirm dialog |
| `bulk_selection` | `checkbox_select` | checkbox selection |

### 8.3 Architectural Flow

```
Natural Language
       ↓
   Intent Analyzer
       ↓
     SUIS
       ↓
  Semantic Validator
       ↓
  Semantic Graph
       ↓
 Framework Adapter
       ↓
     Code
```

---

## Appendix A: Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-27 | Initial release |
| 1.1 | 2026-01-27 | Added `width_hint`, `align_hint`, `editable`, `required` field hints; added `activate_item`, `confirm_action`, `value_change` triggers; added `success_feedback`, `post_action` operation hints; added `integer`, `decimal`, `datetime` formats |
| 1.1 | 2026-01-29 | Restructured to language standard format; removed "Migration from Current UiSpec" section |

---

## Appendix B: Full JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://coder.local/schemas/suis/v1.1/root.schema.json",
  "title": "Semantic UI Specification (SUIS) v1.1",
  "description": "Intent-driven universal UI intermediate representation for UASL semantic compiler",
  "type": "object",
  "required": ["ui"],
  "properties": {
    "ui": {
      "type": "object",
      "required": ["suis_version", "screens"],
      "properties": {
        "suis_version": {
          "type": "string",
          "enum": ["1.1"],
          "description": "SUIS specification version"
        },
        "screens": {
          "type": "object",
          "minProperties": 1,
          "additionalProperties": { "$ref": "#/$defs/screen" },
          "description": "Map of screen ID to screen definition"
        },
        "components": {
          "type": "object",
          "additionalProperties": { "$ref": "#/$defs/component" },
          "description": "Reusable component definitions"
        }
      },
      "additionalProperties": false
    }
  },

  "$defs": {
    "screen": {
      "type": "object",
      "required": ["subject", "display", "operations"],
      "properties": {
        "subject": { "$ref": "#/$defs/subject" },
        "display": { "$ref": "#/$defs/display" },
        "operations": {
          "type": "array",
          "minItems": 1,
          "items": { "$ref": "#/$defs/operation" },
          "description": "User operations available on this screen"
        },
        "navigation": {
          "type": "object",
          "additionalProperties": { "$ref": "#/$defs/navigation" },
          "description": "Navigation targets from this screen"
        },
        "permissions": {
          "type": "object",
          "properties": {
            "roles": {
              "type": "array",
              "items": { "type": "string" },
              "description": "Roles allowed to access this screen"
            }
          },
          "additionalProperties": false
        }
      },
      "additionalProperties": false
    },

    "subject": {
      "type": "object",
      "required": ["domain", "purpose", "title"],
      "properties": {
        "domain": {
          "type": "string",
          "description": "Entity name (MUST exist in entity-spec)"
        },
        "purpose": {
          "type": "string",
          "enum": ["browse", "view", "create", "edit", "dashboard", "wizard"],
          "description": "Screen purpose/intent"
        },
        "title": {
          "type": "string",
          "description": "Human-readable screen title"
        },
        "description": {
          "type": "string",
          "description": "Optional screen description"
        }
      },
      "additionalProperties": false
    },

    "display": {
      "type": "object",
      "required": ["primary"],
      "properties": {
        "primary": {
          "$ref": "#/$defs/display_block",
          "description": "Primary display area"
        },
        "secondary": {
          "type": "array",
          "items": { "$ref": "#/$defs/display_block" },
          "description": "Secondary display areas (KPIs, sidebars)"
        },
        "filters": {
          "type": "array",
          "items": { "$ref": "#/$defs/filter" },
          "description": "Filter definitions for browse/search"
        }
      },
      "additionalProperties": false
    },

    "display_block": {
      "type": "object",
      "required": ["type", "fields"],
      "properties": {
        "type": {
          "type": "string",
          "enum": ["collection", "single", "summary"],
          "description": "Display block type"
        },
        "fields": {
          "type": "array",
          "minItems": 1,
          "items": { "$ref": "#/$defs/field" },
          "description": "Fields to display"
        }
      },
      "additionalProperties": false
    },

    "field": {
      "type": "object",
      "required": ["name"],
      "properties": {
        "name": {
          "type": "string",
          "description": "Entity field name"
        },
        "label": {
          "type": "string",
          "description": "Display label"
        },
        "format": {
          "type": "string",
          "enum": ["text", "integer", "decimal", "currency", "date", "datetime", "enum", "boolean"],
          "description": "Data format for display"
        },
        "sortable": {
          "type": "boolean",
          "description": "Allow sorting by this field"
        },
        "visible": {
          "type": "boolean",
          "default": true,
          "description": "Field visibility"
        },
        "width_hint": {
          "type": "string",
          "enum": ["narrow", "medium", "wide", "fill"],
          "description": "Width hint for adapters"
        },
        "align_hint": {
          "type": "string",
          "enum": ["start", "center", "end"],
          "description": "Alignment hint for adapters"
        },
        "editable": {
          "type": "boolean",
          "description": "Allow inline editing"
        },
        "required": {
          "type": "boolean",
          "description": "Validation: field is required"
        }
      },
      "additionalProperties": false
    },

    "filter": {
      "type": "object",
      "required": ["field", "operator"],
      "properties": {
        "field": {
          "type": "string",
          "description": "Entity field to filter on"
        },
        "operator": {
          "type": "string",
          "enum": ["eq", "ne", "gt", "lt", "range", "contains"],
          "description": "Filter operator"
        },
        "input": {
          "type": "string",
          "enum": ["dropdown", "text", "date_range"],
          "description": "Input control type"
        },
        "options": {
          "type": "array",
          "items": {},
          "description": "Options for dropdown input"
        }
      },
      "additionalProperties": false
    },

    "operation": {
      "type": "object",
      "required": ["intent"],
      "properties": {
        "intent": {
          "type": "string",
          "enum": [
            "browse", "view", "search",
            "create", "edit", "delete",
            "submit",
            "approve", "reject",
            "export", "import",
            "custom"
          ],
          "description": "User intent/action type"
        },
        "opens": {
          "type": "string",
          "description": "Target screen to open"
        },
        "trigger": {
          "type": "string",
          "enum": [
            "select_item",
            "activate_item",
            "bulk_selection",
            "confirm_action",
            "value_change",
            "automatic"
          ],
          "description": "Semantic trigger (NOT DOM event)"
        },
        "confirmation": {
          "type": "string",
          "description": "Confirmation message (required for delete)"
        },
        "success_feedback": {
          "type": "string",
          "description": "Message shown on success"
        },
        "post_action": {
          "type": "string",
          "enum": ["refresh", "close", "navigate"],
          "description": "Action after completion"
        }
      },
      "additionalProperties": false
    },

    "navigation": {
      "type": "object",
      "required": ["target"],
      "properties": {
        "target": {
          "type": "string",
          "description": "Target screen ID"
        },
        "mode": {
          "type": "string",
          "enum": ["modal", "full"],
          "default": "full",
          "description": "Navigation mode"
        }
      },
      "additionalProperties": false
    },

    "component": {
      "type": "object",
      "required": ["type", "fields"],
      "properties": {
        "type": {
          "type": "string",
          "enum": ["summary", "collection"],
          "description": "Component type"
        },
        "fields": {
          "type": "array",
          "minItems": 1,
          "items": { "$ref": "#/$defs/field" },
          "description": "Component fields"
        }
      },
      "additionalProperties": false
    }
  }
}
```

---

*Document Version: 1.1*
*Last Updated: 2026-01-29*
