# Workflow Spec v1.0 — State Machine Specification

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Status** | Candidate Recommendation |
| **Date** | 2026-01-29 |
| **JSON Schema** | `schemas/workflow/v1.0/root.schema.json` |
| **Depends On** | Entity Spec v1.0 |
| **Depended On By** | SUIS v1.1 (optional), IAS v1.0 (optional) |

---

## Abstract

The Workflow Spec defines state machines for business processes — approval workflows, order lifecycles, task progression, and other stateful domain flows. Each workflow is bound to an entity and its status field, declaring states, transitions, guard conditions, and side-effect actions in a framework-agnostic, machine-verifiable format.

Workflow Spec은 비즈니스 프로세스를 위한 상태 기계를 정의합니다 — 승인 워크플로, 주문 수명주기, 업무 진행 등 상태를 가진 도메인 흐름을 기술합니다. 각 워크플로는 엔티티와 그 상태 필드에 바인딩되어, 상태(State), 전이(Transition), 가드 조건(Guard), 부수 효과 액션(Action)을 프레임워크에 종속되지 않는 기계 검증 가능한 형식으로 선언합니다.

---

## 1. Introduction

### 1.1 Purpose

The Workflow Spec provides a declarative way to define state machines that govern entity lifecycle. Typical use cases include:

- Document approval (draft → pending → approved/rejected)
- Order processing (created → paid → shipped → delivered)
- Task lifecycle (todo → in_progress → review → done)

### 1.2 Scope

This specification defines:

- State definitions with types (initial, normal, final), hooks, and permissions
- Transition definitions with events, role restrictions, and comment requirements
- Guard conditions (simple and compound) with operators
- Actions (side effects) for state entry, exit, and transitions
- Structural, semantic, and cross-spec validation rules

### 1.3 Relationship to Other UASL Specs

- **Entity Spec** — `workflow.entity` references an entity; `status_field` MUST be an enum attribute; guard `field` references entity attributes
- **SUIS** — workflow operations (`approve`, `reject`) appear as SUIS operation intents
- **IAS** — workflow transition events MAY have corresponding IAS intent bindings

See [UASL Overview](UASL_OVERVIEW.md) for the full dependency graph.

---

## 2. Conformance

### 2.1 Conformance Levels

| Level | Requirements |
|-------|-------------|
| **L1 Structural** | Document passes JSON Schema validation (`schemas/workflow/v1.0/root.schema.json`) |
| **L2 Semantic** | L1 + exactly one `initial` state; at least one `final` state; all `from`/`to` reference existing states; all states reachable; all final states reachable |
| **L3 Complete** | L2 + `entity` exists in Entity Spec; `status_field` is an enum attribute; state names match enum values; guard fields exist on entity |

### 2.2 RFC 2119 Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

---

## 3. Terminology

| Term | Korean | Definition |
|------|--------|------------|
| **State** | 상태 | A named position in the workflow state machine |
| **Transition** | 전이 | A directed edge from one state to another, triggered by an event |
| **Event** | 이벤트 | A named action that triggers a transition (e.g., `submit`, `approve`, `reject`) |
| **Guard** | 가드 조건 | A boolean condition that MUST be true for a transition to fire |
| **Action** | 액션 | A side effect executed on state entry, exit, or transition |
| **Initial State** | 초기 상태 | The starting state; exactly one per workflow |
| **Final State** | 최종 상태 | A terminal state; at least one per workflow |
| **Status Field** | 상태 필드 | The entity attribute (enum type) that holds the current workflow state |

---

## 4. Specification (NORMATIVE)

### 4.1 Design Principles

1. **Entity-bound** — each workflow belongs to exactly one entity.
2. **Explicit states** — all states MUST be declared; no implicit states.
3. **Typed transitions** — events trigger state changes with declared from/to.
4. **Guarded transitions** — optional conditions on transitions prevent invalid state changes.
5. **Action hooks** — side effects on state entry, exit, and transition.

### 4.2 Document Structure

A conforming Workflow Spec document MUST contain:

```yaml
workflow:
  version: "1.0"           # REQUIRED
  entity: document          # REQUIRED — entity name from Entity Spec
  status_field: status      # REQUIRED — enum attribute on entity

  states:                    # REQUIRED — at least 2 states
    state_name: { ... }

  transitions:               # REQUIRED — at least 1 transition
    - { ... }
```

- `version` MUST be the string `"1.0"`.
- `entity` MUST name an entity defined in the Entity Spec.
- `status_field` MUST name an enum attribute on the referenced entity.
- `states` MUST contain at least 2 entries.
- `transitions` MUST contain at least 1 entry.

### 4.3 State Definition

Each state MUST declare a `type`.

```yaml
states:
  draft:
    type: initial                  # REQUIRED — initial | normal | final
    label: "Draft"                 # OPTIONAL — human-readable name
    description: "Being edited"    # OPTIONAL
    on_enter: [ ... ]              # OPTIONAL — actions on entering state
    on_exit: [ ... ]               # OPTIONAL — actions on leaving state
    permissions:                   # OPTIONAL — role-based access
      view: [author, admin]
      edit: [author]
```

#### 4.3.1 State Types

| Type | Description | Constraints |
|------|-------------|-------------|
| `initial` | Starting state | Exactly one per workflow |
| `normal` | Intermediate state | Zero or more |
| `final` | Terminal state | At least one per workflow |

#### 4.3.2 State Hooks

- `on_enter` — OPTIONAL array of actions executed when entering this state.
- `on_exit` — OPTIONAL array of actions executed when leaving this state.

#### 4.3.3 State Permissions

State-level permissions declare who can view or edit the entity when it is in this state.

```yaml
permissions:
  view: [author, approver, admin]    # Roles that can view
  edit: [author]                      # Roles that can edit
```

An empty array (`edit: []`) means no role can edit in this state.

### 4.4 Transition Definition

Each transition MUST declare `event`, `from`, and `to`.

```yaml
transitions:
  - event: submit                    # REQUIRED — event name
    from: draft                      # REQUIRED — source state
    to: pending_approval             # REQUIRED — target state
    label: "Submit for Approval"    # OPTIONAL
    guard: { ... }                   # OPTIONAL — condition
    action: [ ... ]                  # OPTIONAL — side effects
    allowed_roles: [author]          # OPTIONAL — role restriction
    requires_comment: true           # OPTIONAL — comment required
```

- `event` is the name of the triggering action.
- `from` MUST name an existing state.
- `to` MUST name an existing state.
- `allowed_roles` restricts which roles can trigger this transition.
- `requires_comment` indicates the user MUST provide a comment (e.g., rejection reason).

### 4.5 Guard Conditions

Guards are conditions that MUST be true for a transition to fire.

#### 4.5.1 Simple Guard

```yaml
guard:
  field: amount
  operator: gt
  value: 0
```

#### 4.5.2 Compound Guard (AND)

```yaml
guard:
  all:
    - field: amount
      operator: gt
      value: 0
    - field: attachments
      operator: not_empty
```

#### 4.5.3 Compound Guard (OR)

```yaml
guard:
  any:
    - field: priority
      operator: eq
      value: high
    - field: escalated
      operator: eq
      value: true
```

#### 4.5.4 Guard Operators

| Operator | Description | Value Required |
|----------|-------------|----------------|
| `eq` | Equal to | Yes |
| `ne` | Not equal to | Yes |
| `gt` | Greater than | Yes |
| `gte` | Greater than or equal | Yes |
| `lt` | Less than | Yes |
| `lte` | Less than or equal | Yes |
| `contains` | String/array contains | Yes |
| `not_empty` | Field is not empty/null | No |
| `is_empty` | Field is empty/null | No |
| `in` | Value is in list | Yes (array) |

### 4.6 Actions

Actions are side effects triggered on state transitions or entry/exit.

```yaml
action:
  - action: notify
    params:
      role: approver
      template: approval_request

  - action: set_field
    params:
      field: approved_at
      value: $now
```

#### 4.6.1 Built-in Action Types

| Action | Description | Common Params |
|--------|-------------|---------------|
| `notify` | Send notification to role/user | `role`, `template` |
| `email` | Send email | `to`, `template` |
| `log` | Log event | `level`, `message` |
| `webhook` | Call HTTP endpoint | `url`, `method` |
| `set_field` | Update entity field value | `field`, `value` |

#### 4.6.2 Parameter Variables

Actions MAY use variable references in `params.value`:

| Variable | Description |
|----------|-------------|
| `$now` | Current timestamp |
| `$author.email` | Email of the entity author |

### 4.7 Validation Rules

#### 4.7.1 Structural Validation (L1 + L2)

| Rule | Error Code |
|------|------------|
| `version` MUST equal `"1.0"` | `INVALID_VERSION` |
| `states` MUST have at least 2 entries | `TOO_FEW_STATES` |
| Exactly one state with `type: initial` | `INVALID_INITIAL_STATE` |
| At least one state with `type: final` | `NO_FINAL_STATE` |
| `transitions` MUST have at least 1 entry | `NO_TRANSITIONS` |

#### 4.7.2 Semantic Validation (L2)

| Rule | Error Code |
|------|------------|
| Transition `from` MUST name an existing state | `UNKNOWN_FROM_STATE` |
| Transition `to` MUST name an existing state | `UNKNOWN_TO_STATE` |
| All states MUST be reachable from the initial state | `UNREACHABLE_STATE` |
| At least one path MUST exist to each final state | `DEAD_END_STATE` |

#### 4.7.3 Cross-Spec Validation (L3)

| Rule | Error Code |
|------|------------|
| `entity` MUST exist in Entity Spec | `UNKNOWN_ENTITY` |
| `status_field` MUST be an enum attribute on the entity | `INVALID_STATUS_FIELD` |
| State names MUST match the `status_field` enum values | `STATE_ENUM_MISMATCH` |
| Guard `field` MUST exist in entity attributes | `UNKNOWN_GUARD_FIELD` |
| SUIS screens referencing workflow MUST use valid workflow states | `INVALID_WORKFLOW_REFERENCE` |

**Fail-fast. No silent coercion.**

---

## 5. Cross-Spec References (NORMATIVE)

### 5.1 Workflow → Entity Spec

Each workflow is bound to an entity:

```yaml
workflow:
  entity: document          # MUST exist in entity-spec.entities
  status_field: status      # MUST be an enum attribute on document
```

State names MUST match the enum `values` of `status_field`. The semantic validator checks this bidirectionally.

Guard conditions reference entity attributes:

```yaml
guard:
  field: amount             # MUST exist in entity.attributes
  operator: gt
  value: 0
```

### 5.2 Workflow → SUIS

SUIS screens display workflow operations as user intents:

```yaml
# SUIS operation for workflow transition
operations:
  - intent: approve
    trigger: confirm_action
    success_feedback: "Document approved"
    post_action: close
```

The `approve` and `reject` intents in SUIS correspond to workflow transition events.

### 5.3 Workflow → IAS

Workflow transition events MAY have corresponding IAS intent bindings:

```yaml
# IAS intent for workflow transition
intents:
  approve:
    method: POST
    path_suffix: "/{id}/approve"
    returns: single
```

---

## 6. JSON Schema Reference

The normative JSON Schema for Workflow Spec v1.0 is located at:

```
schemas/workflow/v1.0/root.schema.json
```

Key features of the schema:

- Enforces `workflow` with `version`, `entity`, `status_field`, `states`, and `transitions` as required
- Validates state types against `initial`, `normal`, `final`
- Validates guard structure with `oneOf` for simple/compound guards
- Validates guard operators against a fixed enum
- Validates action types against `notify`, `email`, `log`, `webhook`, `set_field`
- Disallows additional properties at all levels

See [Appendix B](#appendix-b-full-json-schema) for an inline copy.

---

## 7. Examples (INFORMATIVE)

### 7.1 Complete Workflow Spec

```yaml
workflow:
  version: "1.0"
  entity: document
  status_field: status

  states:
    draft:
      type: initial
      label: "Draft"
      description: "Document is being prepared"
      permissions:
        view: [author, admin]
        edit: [author]

    pending:
      type: normal
      label: "Pending Approval"
      on_enter:
        - action: notify
          params: { role: approver, template: approval_needed }
      permissions:
        view: [author, approver, admin]
        edit: []

    approved:
      type: final
      label: "Approved"
      on_enter:
        - action: set_field
          params: { field: approved_at, value: $now }
        - action: notify
          params: { role: author, template: document_approved }
      permissions:
        view: [all]
        edit: []

    rejected:
      type: final
      label: "Rejected"
      on_enter:
        - action: notify
          params: { role: author, template: document_rejected }
      permissions:
        view: [author, approver, admin]
        edit: []

  transitions:
    - event: submit
      from: draft
      to: pending
      label: "Submit for Approval"
      guard:
        all:
          - field: title
            operator: not_empty
          - field: content
            operator: not_empty

    - event: approve
      from: pending
      to: approved
      label: "Approve"
      allowed_roles: [approver, admin]

    - event: reject
      from: pending
      to: rejected
      label: "Reject"
      allowed_roles: [approver, admin]
      requires_comment: true

    - event: revise
      from: rejected
      to: draft
      label: "Revise"
      allowed_roles: [author]
```

---

## 8. Implementation Notes (INFORMATIVE)

### 8.1 Code Generation Guidance

A conforming compiler can generate state machine code from the Workflow Spec. The generated code should include:

- Enum type for states
- Event/transition type definitions
- Guard evaluation functions
- State transition function with validation
- Action dispatch on state entry/exit/transition

The generated code is deterministic: identical specs produce identical output.

### 8.2 SUIS Integration Patterns

SUIS screens can render workflow-aware UIs:

```yaml
# SUIS screen for pending approval
screens:
  document_approval:
    subject:
      domain: document
      purpose: edit
      title: "Review Document"

    display:
      primary:
        type: single
        fields:
          - name: title
          - name: content
          - name: status
            format: enum

    operations:
      - intent: approve
        trigger: confirm_action
        success_feedback: "Document approved"
        post_action: close

      - intent: reject
        trigger: confirm_action
        confirmation: "Enter rejection reason"
        post_action: close
```

### 8.3 IAS Integration Patterns

IAS provides HTTP bindings for workflow transitions:

```yaml
# IAS resource with workflow intents
resources:
  document:
    path: /api/documents
    entity: document

    intents:
      approve:
        method: POST
        path_suffix: "/{id}/approve"
        returns: single

      reject:
        method: POST
        path_suffix: "/{id}/reject"
        body_from: form
        returns: single
```

---

## Appendix A: Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-27 | Initial release |
| 1.0 | 2026-01-29 | Restructured to language standard format |

---

## Appendix B: Full JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://coder.local/schemas/workflow/v1.0/root.schema.json",
  "title": "Workflow Specification v1.0",
  "description": "State machine specification for approval and business flows",
  "type": "object",
  "required": ["workflow"],
  "properties": {
    "workflow": {
      "type": "object",
      "required": ["version", "entity", "status_field", "states", "transitions"],
      "properties": {
        "version": {
          "type": "string",
          "enum": ["1.0"],
          "description": "Workflow spec version"
        },
        "entity": {
          "type": "string",
          "description": "Entity this workflow applies to (must exist in entity-spec)"
        },
        "status_field": {
          "type": "string",
          "description": "Entity field that holds the workflow state"
        },
        "states": {
          "type": "object",
          "minProperties": 2,
          "additionalProperties": { "$ref": "#/$defs/state" },
          "description": "Map of state name to state definition"
        },
        "transitions": {
          "type": "array",
          "minItems": 1,
          "items": { "$ref": "#/$defs/transition" },
          "description": "List of state transitions"
        }
      },
      "additionalProperties": false
    }
  },

  "$defs": {
    "state": {
      "type": "object",
      "required": ["type"],
      "properties": {
        "type": {
          "type": "string",
          "enum": ["initial", "normal", "final"],
          "description": "State type (initial=start, final=end)"
        },
        "label": {
          "type": "string",
          "description": "Human-readable state name"
        },
        "description": {
          "type": "string",
          "description": "State description"
        },
        "on_enter": {
          "type": "array",
          "items": { "$ref": "#/$defs/action" },
          "description": "Actions to execute when entering this state"
        },
        "on_exit": {
          "type": "array",
          "items": { "$ref": "#/$defs/action" },
          "description": "Actions to execute when leaving this state"
        },
        "permissions": {
          "$ref": "#/$defs/permissions",
          "description": "Role-based permissions for this state"
        }
      },
      "additionalProperties": false
    },

    "transition": {
      "type": "object",
      "required": ["event", "from", "to"],
      "properties": {
        "event": {
          "type": "string",
          "description": "Event name that triggers this transition"
        },
        "from": {
          "type": "string",
          "description": "Source state name"
        },
        "to": {
          "type": "string",
          "description": "Target state name"
        },
        "label": {
          "type": "string",
          "description": "Human-readable transition label"
        },
        "guard": {
          "$ref": "#/$defs/guard",
          "description": "Condition that must be true for transition"
        },
        "action": {
          "type": "array",
          "items": { "$ref": "#/$defs/action" },
          "description": "Actions to execute on transition"
        },
        "allowed_roles": {
          "type": "array",
          "items": { "type": "string" },
          "description": "Roles allowed to trigger this transition"
        },
        "requires_comment": {
          "type": "boolean",
          "description": "Whether a comment is required for this transition"
        }
      },
      "additionalProperties": false
    },

    "guard": {
      "type": "object",
      "description": "Condition for transition",
      "oneOf": [
        { "$ref": "#/$defs/simple_guard" },
        {
          "type": "object",
          "required": ["all"],
          "properties": {
            "all": {
              "type": "array",
              "items": { "$ref": "#/$defs/simple_guard" },
              "description": "All conditions must be true (AND)"
            }
          },
          "additionalProperties": false
        },
        {
          "type": "object",
          "required": ["any"],
          "properties": {
            "any": {
              "type": "array",
              "items": { "$ref": "#/$defs/simple_guard" },
              "description": "Any condition must be true (OR)"
            }
          },
          "additionalProperties": false
        }
      ]
    },

    "simple_guard": {
      "type": "object",
      "required": ["field", "operator"],
      "properties": {
        "field": {
          "type": "string",
          "description": "Entity field to check"
        },
        "operator": {
          "type": "string",
          "enum": ["eq", "ne", "gt", "gte", "lt", "lte", "contains", "not_empty", "is_empty", "in"],
          "description": "Comparison operator"
        },
        "value": {
          "description": "Value to compare against (optional for not_empty/is_empty)"
        }
      },
      "additionalProperties": false
    },

    "action": {
      "type": "object",
      "required": ["action"],
      "properties": {
        "action": {
          "type": "string",
          "enum": ["notify", "email", "log", "webhook", "set_field"],
          "description": "Action type"
        },
        "params": {
          "type": "object",
          "description": "Action-specific parameters"
        }
      },
      "additionalProperties": false
    },

    "permissions": {
      "type": "object",
      "properties": {
        "view": {
          "type": "array",
          "items": { "type": "string" },
          "description": "Roles that can view in this state"
        },
        "edit": {
          "type": "array",
          "items": { "type": "string" },
          "description": "Roles that can edit in this state"
        }
      },
      "additionalProperties": false
    }
  }
}
```

---

*Document Version: 1.0*
*Last Updated: 2026-01-29*
