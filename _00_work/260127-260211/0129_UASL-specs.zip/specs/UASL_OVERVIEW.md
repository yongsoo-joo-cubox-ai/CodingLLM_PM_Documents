# UASL — Universal Application Specification Language

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Status** | Candidate Recommendation |
| **Date** | 2026-01-29 |
| **Editors** | Coder Team |
| **Spec Family** | UASL (Entity, SUIS, IAS, Workflow) |

---

## Abstract

**UASL (Universal Application Specification Language)** is a family of four declarative specifications that together describe a complete application at the semantic level — domain model, user interface intent, API contract, and business workflow — without coupling to any framework, programming language, or runtime.

UASL enables deterministic compilation: a conforming compiler can transform UASL documents into production code for any target platform, producing identical output from identical input, with no AI in the generation pipeline.

**UASL(Universal Application Specification Language)**은 도메인 모델, UI 의도, API 계약, 비즈니스 워크플로를 의미론적 수준에서 기술하는 4개의 선언적 사양 패밀리입니다. 특정 프레임워크, 프로그래밍 언어, 런타임에 종속되지 않으며, UASL 문서로부터 결정론적 컴파일을 통해 모든 대상 플랫폼의 프로덕션 코드를 생성할 수 있습니다.

---

## 1. Introduction

### 1.1 Purpose

UASL provides a machine-verifiable, framework-agnostic way to describe applications. A developer or AI system authors UASL documents; a compiler transforms them into platform-specific code. The specification boundary ensures:

- **Portability** — the same UASL documents target xframe5, Vue, React, or any future framework.
- **Determinism** — identical specs produce identical artifacts, every time.
- **Verifiability** — structural and semantic validation catches errors before code generation.
- **Separation of concerns** — intent is separated from implementation.

### 1.2 Scope

UASL covers:

- **Domain modeling** (entities, attributes, relations, computed fields)
- **UI intent** (screens, display blocks, operations, navigation, permissions)
- **API contracts** (intent-to-HTTP mapping, parameter sources, return types)
- **Business workflows** (state machines, transitions, guards, actions)

UASL does NOT cover:

- Layout, styling, or pixel positioning (adapter responsibility)
- Framework-specific widgets or components (adapter responsibility)
- Runtime behavior or deployment topology
- Authentication/authorization implementation (only declares roles)

### 1.3 Design Philosophy

| Principle | Description |
|-----------|-------------|
| **Semantic over syntactic** | Describe WHAT, not HOW |
| **Intent over implementation** | `intent: search`, not `GET /api/tasks?q=...` |
| **Framework-agnostic** | No framework concepts leak into specs |
| **Machine-verifiable** | Every spec is validated against a JSON Schema and semantic rules |
| **Fail-fast** | Invalid specs produce errors immediately; no silent coercion |

---

## 2. Layered Architecture

UASL consists of four specifications organized in a dependency hierarchy:

```
                    ┌─────────────────────┐
                    │    Entity Spec      │
                    │  (Domain Truth)     │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                │                ▼
   ┌──────────────────┐       │     ┌──────────────────┐
   │   SUIS v1.1      │       │     │   IAS v1.0       │
   │  (UI Intent)     │◄──────┼────►│  (API Contract)  │
   └────────┬─────────┘       │     └──────────────────┘
            │                 │
            │          ┌──────┴──────────┐
            └─────────►│ Workflow v1.0   │
                       │ (State Machine) │
                       └─────────────────┘
```

**Dependency rules:**

| Spec | Depends On | Depended On By |
|------|------------|----------------|
| Entity Spec | (none) | SUIS, IAS, Workflow |
| SUIS | Entity Spec, IAS | Workflow (optional) |
| IAS | Entity Spec | SUIS |
| Workflow | Entity Spec | SUIS (optional), IAS (optional) |

**Validation order:** Entity Spec → IAS → SUIS → Workflow

---

## 3. Spec Family Summary

| Spec | Version | Purpose | JSON Schema |
|------|---------|---------|-------------|
| [Entity Spec](ENTITY_SPEC.md) | 1.0 | Domain model: entities, attributes, relations, computed fields | `schemas/entity/v1.0/root.schema.json` |
| [SUIS](SUIS_SCHEMA.md) | 1.1 | UI intent: screens, display, operations, navigation, permissions | `schemas/suis/v1.1/root.schema.json` |
| [IAS](IAS_SCHEMA.md) | 1.0 | API contract: intent-to-HTTP mapping, parameter sources, return types | `schemas/ias/v1.0/root.schema.json` |
| [Workflow Spec](WORKFLOW_SPEC.md) | 1.0 | Business workflows: states, transitions, guards, actions | `schemas/workflow/v1.0/root.schema.json` |

---

## 4. Conformance

### 4.1 Conformance Levels

UASL defines three conformance levels. A compiler or toolchain claims conformance at a specific level.

| Level | Name | Requirements |
|-------|------|--------------|
| **L1** | Structural | Document passes JSON Schema validation |
| **L2** | Semantic | L1 + all cross-field and intra-spec semantic rules pass |
| **L3** | Complete | L2 + all cross-spec referential integrity rules pass |

**L1 Structural** conformance verifies that a document matches the JSON Schema for its spec type. This includes required fields, type constraints, and enum values.

**L2 Semantic** conformance adds intra-spec rules that JSON Schema cannot express. For example: an Entity Spec's `primary_key` value MUST name an attribute that exists in the same entity; a Workflow's `initial` state MUST be exactly one.

**L3 Complete** conformance adds cross-spec referential integrity. For example: a SUIS `subject.domain` MUST reference an entity defined in the Entity Spec; every SUIS intent MUST have a corresponding IAS mapping.

### 4.2 RFC 2119 Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in UASL specifications are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

- **MUST / REQUIRED / SHALL** — absolute requirement
- **MUST NOT / SHALL NOT** — absolute prohibition
- **SHOULD / RECOMMENDED** — valid reasons to ignore exist, but full implications must be understood
- **MAY / OPTIONAL** — truly optional

All NORMATIVE sections use uppercase keywords. INFORMATIVE sections do not.

---

## 5. Terminology

Shared glossary for all UASL specifications. Korean annotations (한국어 주석) are provided for bilingual teams.

| Term | Korean | Definition |
|------|--------|------------|
| **Entity** | 엔티티 | A domain object with attributes and relations (e.g., Task, User) |
| **Attribute** | 속성 | A named, typed field belonging to an entity (e.g., `title: string`) |
| **Relation** | 관계 | A typed link between entities (e.g., `many_to_one`, `one_to_many`) |
| **Screen** | 화면 | A SUIS unit describing a user-facing view with display, operations, and navigation |
| **Intent** | 의도 | A semantic operation the user wants to perform (e.g., `search`, `create`, `approve`) |
| **Trigger** | 트리거 | A semantic user interaction that initiates an operation (e.g., `activate_item`, `bulk_selection`) |
| **Guard** | 가드 조건 | A condition that MUST be true for a workflow transition to fire |
| **Action** | 액션 | A side effect executed on state entry, exit, or transition (e.g., `notify`, `set_field`) |
| **Adapter** | 어댑터 | A framework-specific compiler that transforms UASL IR into platform code |
| **Compiler** | 컴파일러 | A toolchain that validates and transforms UASL specs into target artifacts |
| **Canonical** | 정규 | The authoritative, validated form of a spec (as opposed to draft or inferred) |
| **Domain** | 도메인 | The subject area an entity belongs to (maps to `subject.domain` in SUIS) |
| **Normative** | 규범적 | Sections containing binding requirements (MUST/SHALL) |
| **Informative** | 참고용 | Sections containing guidance, examples, or explanations (non-binding) |
| **Display Block** | 표시 블록 | A SUIS structure defining visible data (collection, single, or summary) |
| **Parameter Source** | 파라미터 소스 | Where an IAS intent gets its data (`filters`, `form`, `selection[]`, `context`) |
| **Return Type** | 반환 타입 | What an IAS intent returns (`collection`, `single`, `none`) |
| **State** | 상태 | A named position in a workflow state machine |
| **Transition** | 전이 | A directed edge between workflow states, triggered by an event |
| **Fail-fast** | 즉시 실패 | Validation strategy: reject invalid specs immediately, never coerce silently |

---

## 6. Serialization Format

### 6.1 Authoring Format

UASL documents SHOULD be authored in **YAML**. YAML provides readability and supports comments, making it suitable for human authoring and code review.

### 6.2 Validation Format

UASL documents MUST be validated against **JSON Schema** (Draft 2020-12). YAML documents are converted to JSON for validation. Each spec provides a corresponding JSON Schema file in the `schemas/` directory.

### 6.3 Schema File Locations

```
schemas/
├── entity/v1.0/
│   └── root.schema.json
├── suis/v1.1/
│   └── root.schema.json
├── ias/v1.0/
│   └── root.schema.json
└── workflow/v1.0/
    └── root.schema.json
```

---

## 7. Specification Lifecycle

Each UASL specification progresses through the following stages:

| Stage | Description |
|-------|-------------|
| **Draft** | Initial design. Subject to breaking changes. |
| **Candidate Recommendation** | Feature-complete. Seeking implementation feedback. |
| **Standard** | Stable. Breaking changes require a new major version. |

Current status:

| Spec | Stage |
|------|-------|
| Entity Spec v1.0 | Candidate Recommendation |
| SUIS v1.1 | Candidate Recommendation |
| IAS v1.0 | Candidate Recommendation |
| Workflow Spec v1.0 | Candidate Recommendation |

---

## 8. Version Governance

### 8.1 Versioning Scheme

Each spec uses **major.minor** versioning:

- **Major** version increment: breaking changes (removed fields, changed semantics)
- **Minor** version increment: backward-compatible additions (new optional fields, new enum values)

### 8.2 Backward Compatibility Policy

- A spec at version X.Y MUST accept all documents valid under version X.Z where Z < Y.
- A new major version (e.g., 2.0) MAY break compatibility with the previous major version.
- Migration guidance MUST be provided for major version upgrades.

### 8.3 Cross-Spec Version Dependencies

When specs reference each other, the following compatibility rules apply:

- Entity Spec v1.x is compatible with SUIS v1.x, IAS v1.x, and Workflow v1.x.
- A major version bump in Entity Spec MAY require corresponding bumps in dependent specs.

---

## 9. Cross-Spec Dependency Graph

### 9.1 Reference Directions

```
Entity Spec ◄── SUIS (subject.domain, fields[].name → entity attributes)
Entity Spec ◄── IAS  (resources[].entity → entity name)
Entity Spec ◄── Workflow (workflow.entity, guard.field → entity attributes)
IAS ◄────────── SUIS (operations[].intent → IAS intents)
Workflow ◄───── SUIS (operations[].intent: approve/reject → workflow transitions)
```

### 9.2 Validation Order

Cross-spec validation MUST proceed in this order:

1. **Entity Spec** — standalone validation (no external dependencies)
2. **IAS** — validates `entity` references against Entity Spec
3. **SUIS** — validates `subject.domain` against Entity Spec and `intent` against IAS
4. **Workflow** — validates `entity` and `status_field` against Entity Spec, cross-references SUIS screens

### 9.3 Cross-Spec Validation Rules (L3)

| Rule | Source Spec | Target Spec | Error Code |
|------|-------------|-------------|------------|
| `subject.domain` exists in entities | SUIS | Entity | `UNKNOWN_ENTITY` |
| `fields[].name` exists in entity attributes/relations | SUIS | Entity | `UNKNOWN_FIELD` |
| `operations[].intent` has IAS mapping | SUIS | IAS | `UNMAPPED_INTENT` |
| `resources[].entity` exists in entities | IAS | Entity | `UNKNOWN_ENTITY` |
| `workflow.entity` exists in entities | Workflow | Entity | `UNKNOWN_ENTITY` |
| `workflow.status_field` is enum on entity | Workflow | Entity | `INVALID_STATUS_FIELD` |
| `guard.field` exists in entity attributes | Workflow | Entity | `UNKNOWN_GUARD_FIELD` |
| State names match entity enum values | Workflow | Entity | `STATE_ENUM_MISMATCH` |

---

## 10. Examples (INFORMATIVE)

### 10.1 End-to-End Example: Task Management

This example shows how all four UASL specs work together for a simple task management feature.

#### Entity Spec

```yaml
entity_version: "1.0"

entities:
  task:
    label: Task
    primary_key: id
    meta:
      source: db
    attributes:
      id:
        type: uuid
        required: true
      title:
        type: string
        required: true
        label: "Title"
        constraints:
          max_length: 200
      description:
        type: text
      status:
        type: enum
        values: [draft, pending, approved, rejected]
        default: draft
      due_date:
        type: date
      created_at:
        type: datetime
        required: true
        default: now()
        readonly: true
      assignee_id:
        type: uuid
    relations:
      assignee:
        type: many_to_one
        target: user
        foreign_key: assignee_id
        display_field: name
        nullable: true
        on_delete: set_null
    display:
      default_sort: created_at desc
      default_fields: [title, status, assignee, due_date]

  user:
    label: User
    primary_key: id
    attributes:
      id:
        type: uuid
        required: true
      name:
        type: string
        required: true
      email:
        type: string
        required: true
        unique: true
    relations:
      tasks:
        type: one_to_many
        target: task
        mapped_by: assignee
```

#### IAS (Intent API Specification)

```yaml
api:
  version: "1.0"
  resources:
    task:
      path: /api/tasks
      entity: task
      intents:
        browse:
          method: GET
          returns: collection
        search:
          method: GET
          query_from: filters
          returns: collection
        view:
          method: GET
          path_suffix: "/{id}"
          returns: single
        create:
          method: POST
          body_from: form
          returns: single
        edit:
          method: PUT
          path_suffix: "/{id}"
          body_from: form
          returns: single
        delete:
          method: DELETE
          path_suffix: "/{id}"
          returns: none
        approve:
          method: POST
          path_suffix: "/{id}/approve"
          returns: single
        reject:
          method: POST
          path_suffix: "/{id}/reject"
          body_from: form
          returns: single
      field_map:
        due_date: dueDate
        created_at: createdAt
        assignee_id: assigneeId
```

#### SUIS (Semantic UI Specification)

```yaml
ui:
  suis_version: "1.1"
  screens:
    task_browse:
      subject:
        domain: task
        purpose: browse
        title: "Task Management"
      display:
        primary:
          type: collection
          fields:
            - name: title
              label: "Title"
              format: text
              width_hint: wide
              sortable: true
            - name: status
              label: "Status"
              format: enum
              width_hint: narrow
            - name: assignee
              label: "Assignee"
              format: text
              width_hint: medium
            - name: due_date
              label: "Due Date"
              format: date
              width_hint: medium
              sortable: true
        filters:
          - field: status
            operator: eq
            input: dropdown
            options: [draft, pending, approved, rejected]
      operations:
        - intent: search
        - intent: create
          opens: task_edit
        - intent: edit
          trigger: activate_item
          opens: task_edit
        - intent: delete
          trigger: bulk_selection
          confirmation: "Delete selected tasks?"
      navigation:
        to_editor:
          target: task_edit
          mode: modal
      permissions:
        roles: [admin, manager, user]

    task_edit:
      subject:
        domain: task
        purpose: edit
        title: "Task Editor"
      display:
        primary:
          type: single
          fields:
            - name: title
              label: "Title"
              format: text
              required: true
            - name: description
              label: "Description"
              format: text
            - name: assignee
              label: "Assignee"
              format: text
            - name: due_date
              label: "Due Date"
              format: date
            - name: status
              label: "Status"
              format: enum
      operations:
        - intent: submit
          success_feedback: "Task saved successfully"
          post_action: close
        - intent: approve
          trigger: confirm_action
          success_feedback: "Task approved"
          post_action: close
        - intent: reject
          trigger: confirm_action
          confirmation: "Enter rejection reason"
          post_action: close
      permissions:
        roles: [admin, manager, user]
```

#### Workflow Spec

```yaml
workflow:
  version: "1.0"
  entity: task
  status_field: status

  states:
    draft:
      type: initial
      label: "Draft"
      permissions:
        view: [author, admin]
        edit: [author]
    pending:
      type: normal
      label: "Pending Approval"
      on_enter:
        - action: notify
          params: { role: approver }
      permissions:
        view: [author, approver, admin]
        edit: []
    approved:
      type: final
      label: "Approved"
      on_enter:
        - action: set_field
          params: { field: approved_at, value: $now }
      permissions:
        view: [all]
        edit: []
    rejected:
      type: final
      label: "Rejected"
      permissions:
        view: [author, approver, admin]
        edit: []

  transitions:
    - event: submit
      from: draft
      to: pending
      label: "Submit for Approval"
      guard:
        field: title
        operator: not_empty
    - event: approve
      from: pending
      to: approved
      label: "Approve"
      allowed_roles: [approver, admin]
    - event: reject
      from: pending
      to: rejected
      label: "Reject"
      allowed_roles: [approver, admin]
      requires_comment: true
    - event: revise
      from: rejected
      to: draft
      label: "Revise"
      allowed_roles: [author]
```

### 10.2 How the Specs Connect

In the example above:

1. **Entity Spec** defines `task` and `user` with their attributes and the `assignee` relation.
2. **IAS** maps intents (`browse`, `create`, `approve`, etc.) to HTTP operations on `/api/tasks`.
3. **SUIS** describes two screens (`task_browse`, `task_edit`) that reference `task` as their domain and use intents defined in IAS.
4. **Workflow** defines the approval state machine (`draft → pending → approved/rejected`) bound to the `task` entity's `status` field.

A conforming compiler validates all cross-references (L3), then generates platform-specific code using framework adapters.

---

## Appendix A: Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-29 | Initial release of UASL Overview |

---

*Document Version: 1.0*
*Last Updated: 2026-01-29*
