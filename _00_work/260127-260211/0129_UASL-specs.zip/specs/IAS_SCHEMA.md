# IAS v1.0 — Intent API Specification

## Document Metadata

| Field | Value |
|-------|-------|
| **Version** | 1.0 |
| **Status** | Candidate Recommendation |
| **Date** | 2026-01-29 |
| **JSON Schema** | `schemas/ias/v1.0/root.schema.json` |
| **Depends On** | Entity Spec v1.0 |
| **Depended On By** | SUIS v1.1 |

---

## Abstract

The Intent API Specification (IAS) maps semantic operation intents to concrete HTTP operations. It serves as the bridge between UI intent (defined in SUIS) and backend API contracts, allowing SUIS to remain fully decoupled from URLs, HTTP verbs, and payload structures.

IAS(Intent API Specification)는 의미론적 작업 의도를 구체적인 HTTP 작업에 매핑합니다. SUIS에서 정의된 UI 의도와 백엔드 API 계약 사이의 다리 역할을 하여, SUIS가 URL, HTTP 메서드, 페이로드 구조로부터 완전히 분리될 수 있도록 합니다.

---

## 1. Introduction

### 1.1 Purpose

IAS defines how each semantic intent (e.g., `search`, `create`, `approve`) translates to an HTTP operation (method, path, parameters, return type). This separation ensures that:

- SUIS never contains API details (no URLs, no HTTP verbs, no payloads).
- API changes are isolated to IAS without affecting UI specifications.
- Adapters receive fully resolved HTTP specifications for code generation.

### 1.2 Scope

This specification defines:

- Resource definitions linking entities to API paths
- Intent-to-HTTP mappings (method, path suffix, parameter sources, return types)
- Field name mapping between frontend and backend conventions
- Structural, semantic, and cross-spec validation rules

### 1.3 Relationship to Other UASL Specs

- **Entity Spec** — each IAS resource references an entity via `resources[].entity`
- **SUIS** — each SUIS operation intent MUST have a corresponding IAS intent mapping
- **Workflow** — workflow transition events (approve, reject) MAY have IAS intent bindings

See [UASL Overview](UASL_OVERVIEW.md) for the full dependency graph.

---

## 2. Conformance

### 2.1 Conformance Levels

| Level | Requirements |
|-------|-------------|
| **L1 Structural** | Document passes JSON Schema validation (`schemas/ias/v1.0/root.schema.json`) |
| **L2 Semantic** | L1 + `query_from` only on GET methods; `body_from` only on POST/PUT/PATCH; `path_suffix` with `{id}` has valid context |
| **L3 Complete** | L2 + `entity` references valid Entity Spec entity; every SUIS intent has IAS mapping |

### 2.2 RFC 2119 Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in [RFC 2119](https://www.ietf.org/rfc/rfc2119.txt).

---

## 3. Terminology

| Term | Korean | Definition |
|------|--------|------------|
| **Resource** | 리소스 | An API endpoint group bound to an entity |
| **Intent** | 의도 | A named semantic operation that maps to an HTTP method and path |
| **Parameter Source** | 파라미터 소스 | Where an intent gets its input data (`filters`, `form`, `selection[]`, `context`) |
| **Return Type** | 반환 타입 | What the API returns for an intent (`collection`, `single`, `none`) |
| **Field Map** | 필드 매핑 | Name conversion between spec conventions (snake_case) and backend conventions (camelCase) |
| **Path Suffix** | 경로 접미사 | Additional path appended to the resource base path (e.g., `/{id}`, `/bulk-delete`) |

---

## 4. Specification (NORMATIVE)

### 4.1 Design Principles

1. **One resource per domain** — each `subject.domain` in SUIS maps to exactly one IAS resource.
2. **Intent-driven** — SUIS says "search"; IAS says "GET with query params".
3. **Parameter sources** — where data comes from is explicit (filters, form, selection).
4. **Return types** — what the adapter expects back is declared (collection, single, none).
5. **No UI concepts** — IAS knows HTTP, not widgets.

### 4.2 Document Structure

A conforming IAS document MUST contain:

```yaml
api:
  version: "1.0"          # REQUIRED

  resources:               # REQUIRED — at least one resource
    resource_name: { ... }
```

- `version` MUST be the string `"1.0"`.
- `resources` MUST be a non-empty object where each key is a resource name.

### 4.3 Resource Definition

Each resource MUST contain `path`, `entity`, and `intents`.

```yaml
resources:
  task:
    path: /api/tasks              # REQUIRED — base URL path
    entity: task                   # REQUIRED — entity name from Entity Spec
    intents:                       # REQUIRED — at least one intent
      intent_name: { ... }
    field_map:                     # OPTIONAL — naming conversion
      due_date: dueDate
```

- `path` MUST be a valid URL path starting with `/`.
- `entity` MUST name an entity defined in the Entity Spec.
- `field_map` is OPTIONAL; keys are Entity Spec field names (snake_case), values are backend field names.

### 4.4 Intent Mapping

Each intent MUST declare `method` and `returns`.

```yaml
intents:
  browse:
    method: GET
    returns: collection

  search:
    method: GET
    query_from: filters
    returns: collection

  view:
    method: GET
    path_suffix: "/{id}"
    returns: single

  create:
    method: POST
    body_from: form
    returns: single

  edit:
    method: PUT
    path_suffix: "/{id}"
    body_from: form
    returns: single

  delete:
    method: DELETE
    path_suffix: "/{id}"
    returns: none
```

#### 4.4.1 Method

`method` MUST be one of: `GET`, `POST`, `PUT`, `PATCH`, `DELETE`.

#### 4.4.2 Path Suffix

`path_suffix` is OPTIONAL. When present, it is appended to the resource `path` to form the full URL.

- `{id}` is a path parameter placeholder that MUST be resolved from the current selection context.
- Custom suffixes (e.g., `/bulk-delete`, `/{id}/approve`) are allowed.

#### 4.4.3 Parameter Sources

| Source | Description | Typical Use |
|--------|-------------|-------------|
| `filters` | Query parameters from SUIS filter definitions | `browse`, `search` |
| `form` | Request body from editor field values | `create`, `edit` |
| `selection[]` | Array of IDs from multi-select | `bulk_delete` |
| `context` | Screen state (current ID, parent ID, etc.) | `view`, `edit`, `delete` |

- `query_from` MUST only be used with `GET` methods.
- `body_from` MUST only be used with `POST`, `PUT`, or `PATCH` methods.

#### 4.4.4 Return Types

| Type | Description | Adapter Behavior |
|------|-------------|------------------|
| `collection` | Array of items | Populate grid/list |
| `single` | Single item | Populate form/detail view |
| `none` | No response body expected | Refresh current view |

### 4.5 Bulk Operations

Bulk operations use `selection[]` as the body source:

```yaml
bulk_delete:
  method: POST
  path_suffix: "/bulk-delete"
  body_from: selection[]
  returns: none
```

In SUIS, the corresponding operation uses `trigger: bulk_selection`:

```yaml
operations:
  - intent: delete
    trigger: bulk_selection
```

### 4.6 Workflow Actions

Workflow transition events (e.g., approve, reject) are mapped as custom intents:

```yaml
approve:
  method: POST
  path_suffix: "/{id}/approve"
  returns: single

reject:
  method: POST
  path_suffix: "/{id}/reject"
  body_from: form
  returns: single
```

### 4.7 Field Mapping

The `field_map` converts between Entity Spec naming (snake_case) and backend API naming:

```yaml
field_map:
  due_date: dueDate
  created_at: createdAt
  assignee_id: assigneeId
```

- Keys are Entity Spec attribute names.
- Values are the corresponding backend API field names.
- Adapters MUST apply this mapping when constructing requests and parsing responses.
- Fields not listed in `field_map` are passed through unchanged.

### 4.8 Validation Rules

#### 4.8.1 Structural Validation (L1 + L2)

| Rule | Error Code |
|------|------------|
| `api.version` MUST exist and equal `"1.0"` | `MISSING_VERSION` |
| `resources` MUST NOT be empty | `NO_RESOURCES` |
| `path` MUST be a valid URL path starting with `/` | `INVALID_PATH` |
| `method` MUST be a valid HTTP verb | `INVALID_METHOD` |
| `query_from` MUST only appear on `GET` intents | `INVALID_QUERY_SOURCE` |
| `body_from` MUST only appear on `POST`, `PUT`, or `PATCH` intents | `INVALID_BODY_SOURCE` |

#### 4.8.2 Semantic Validation (L2)

| Rule | Error Code |
|------|------------|
| `path_suffix` with `{id}` requires a selection or context trigger | `MISSING_ID_SOURCE` |

#### 4.8.3 Cross-Spec Validation (L3)

| Rule | Error Code |
|------|------------|
| `entity` MUST exist in Entity Spec | `UNKNOWN_ENTITY` |
| Every SUIS intent MUST have a corresponding IAS intent | `UNMAPPED_INTENT` |
| IAS intent name MUST match a SUIS operation intent | `MISSING_IAS_INTENT` |

**Fail-fast. No silent coercion.**

---

## 5. Cross-Spec References (NORMATIVE)

### 5.1 IAS ← Entity Spec

Each resource references an entity:

```yaml
resources:
  task:
    entity: task    # MUST exist in entity-spec.entities
```

The semantic validator checks that `entity` names a valid entity.

### 5.2 IAS ← SUIS

SUIS operations reference IAS intents by name:

```yaml
# SUIS operation
operations:
  - intent: search    # MUST exist in IAS.resources.task.intents
```

Every SUIS intent MUST have a matching IAS intent. The semantic validator enforces bidirectional consistency.

### 5.3 IAS ← Workflow

Workflow transition events MAY have corresponding IAS intents for HTTP binding:

```yaml
# IAS intent for workflow transition
approve:
  method: POST
  path_suffix: "/{id}/approve"
  returns: single
```

---

## 6. JSON Schema Reference

The normative JSON Schema for IAS v1.0 is located at:

```
schemas/ias/v1.0/root.schema.json
```

Key features of the schema:

- Enforces `api` with `version` and `resources` as required
- Validates HTTP methods against a fixed enum
- Validates parameter sources (`query_from`, `body_from`) against fixed enums
- Validates return types against `collection`, `single`, `none`
- Disallows additional properties at all levels

See [Appendix B](#appendix-b-full-json-schema) for an inline copy.

---

## 7. Examples (INFORMATIVE)

### 7.1 Complete IAS Document

```yaml
api:
  version: "1.0"

  resources:
    task:
      path: /api/tasks
      entity: task

      intents:
        browse:
          method: GET
          returns: collection

        search:
          method: GET
          query_from: filters
          returns: collection

        view:
          method: GET
          path_suffix: "/{id}"
          returns: single

        create:
          method: POST
          body_from: form
          returns: single

        edit:
          method: PUT
          path_suffix: "/{id}"
          body_from: form
          returns: single

        delete:
          method: DELETE
          path_suffix: "/{id}"
          returns: none

        bulk_delete:
          method: POST
          path_suffix: "/bulk-delete"
          body_from: selection[]
          returns: none

        export:
          method: GET
          path_suffix: "/export"
          query_from: filters
          returns: single

      field_map:
        due_date: dueDate
        created_at: createdAt
        assignee_id: assigneeId

    user:
      path: /api/users
      entity: user

      intents:
        browse:
          method: GET
          returns: collection

        view:
          method: GET
          path_suffix: "/{id}"
          returns: single
```

---

## 8. Implementation Notes (INFORMATIVE)

### 8.1 Operation Binding Flow

When a SUIS operation is triggered, the adapter resolves it through IAS:

```
SUIS operation (intent: edit, trigger: activate_item)
     ↓
Semantic Validator (intent exists? entity valid?)
     ↓
IAS Lookup (resources.task.intents.edit)
     ↓
┌─────────────────────────────────────┐
│ Bound Operation:                     │
│   url: /api/tasks/{id}              │
│   method: PUT                        │
│   body: form fields                  │
│   returns: single                    │
└─────────────────────────────────────┘
     ↓
Framework Adapter
     ↓
Generated Code (fetch/axios/etc.)
```

### 8.2 Default IAS Generation

For standard CRUD operations, IAS can be auto-generated from Entity Spec:

```
Entity: task
     ↓
Default IAS:
  - browse: GET /api/tasks → collection
  - search: GET /api/tasks?{filters} → collection
  - view: GET /api/tasks/{id} → single
  - create: POST /api/tasks → single
  - edit: PUT /api/tasks/{id} → single
  - delete: DELETE /api/tasks/{id} → none
```

Custom endpoints (e.g., `approve`, `reject`, `bulk_delete`) MUST be explicitly defined.

### 8.3 What IAS Replaces in SUIS

Prior to IAS, UI specifications embedded API details directly. IAS eliminates:

| Removed from SUIS | Derived From IAS |
|-------------------|-----------------|
| `api_url` | `resource.path` + `path_suffix` |
| `param_source` | `query_from` / `body_from` |
| `result_target` | `returns` type |

---

## Appendix A: Changelog

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-27 | Initial release |
| 1.0 | 2026-01-29 | Restructured to language standard format |

---

## Appendix B: Full JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://coder.local/schemas/ias/v1.0/root.schema.json",
  "title": "Intent API Specification (IAS) v1.0",
  "description": "Map SUIS operation intents to concrete HTTP operations",
  "type": "object",
  "required": ["api"],
  "properties": {
    "api": {
      "type": "object",
      "required": ["version", "resources"],
      "properties": {
        "version": {
          "type": "string",
          "enum": ["1.0"],
          "description": "IAS specification version"
        },
        "resources": {
          "type": "object",
          "minProperties": 1,
          "additionalProperties": { "$ref": "#/$defs/resource" },
          "description": "Map of resource name to resource definition"
        }
      },
      "additionalProperties": false
    }
  },

  "$defs": {
    "resource": {
      "type": "object",
      "required": ["path", "entity", "intents"],
      "properties": {
        "path": {
          "type": "string",
          "pattern": "^/",
          "description": "Base URL path (must start with /)"
        },
        "entity": {
          "type": "string",
          "description": "Entity name (MUST exist in entity-spec)"
        },
        "intents": {
          "type": "object",
          "minProperties": 1,
          "additionalProperties": { "$ref": "#/$defs/intent" },
          "description": "Map of intent name to intent definition"
        },
        "field_map": {
          "type": "object",
          "additionalProperties": { "type": "string" },
          "description": "Field name mapping (snake_case to camelCase)"
        }
      },
      "additionalProperties": false
    },

    "intent": {
      "type": "object",
      "required": ["method", "returns"],
      "properties": {
        "method": {
          "type": "string",
          "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
          "description": "HTTP method"
        },
        "path_suffix": {
          "type": "string",
          "description": "Path suffix appended to resource path"
        },
        "query_from": {
          "type": "string",
          "enum": ["filters", "context"],
          "description": "Source for query parameters"
        },
        "body_from": {
          "type": "string",
          "enum": ["form", "selection[]", "context"],
          "description": "Source for request body"
        },
        "returns": {
          "type": "string",
          "enum": ["collection", "single", "none"],
          "description": "Response type"
        }
      },
      "additionalProperties": false
    }
  }
}
```

---

*Document Version: 1.0*
*Last Updated: 2026-01-29*
